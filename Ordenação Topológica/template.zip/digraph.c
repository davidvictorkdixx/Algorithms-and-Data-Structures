#include "digraph.h"
#include "stack.h"

#include <assert.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct edge EDGE;

struct edge {
};

struct digraph {
};

DIGRAPH *digraph_read() {
}

DIGRAPH *digraph_create(int order) {
}

void digraph_destroy(DIGRAPH *digraph) {
}

static EDGE *digraph_create_edge(int u) {
}

void digraph_add_edge(DIGRAPH *digraph, int u, int v) {
}

bool digraph_has_edge(const DIGRAPH *digraph, int u, int v) {
}

typedef enum { WHITE, GRAY, BLACK } COLOR;

// Returns false if is not dag
static bool topological_sort_dfs(const DIGRAPH *digraph, int u, COLOR *color, STACK *stack) {
}

void topological_sort(const DIGRAPH *digraph) {
}
